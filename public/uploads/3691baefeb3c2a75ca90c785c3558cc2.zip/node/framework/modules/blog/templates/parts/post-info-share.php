<div class ="edgtf-blog-share">
	<?php echo node_edge_get_social_share_html(); ?>
</div>