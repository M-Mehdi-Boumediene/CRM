<div class="edgtf-blog-like">
	<?php if( function_exists('node_edge_get_like') ) node_edge_get_like(); ?>
</div>