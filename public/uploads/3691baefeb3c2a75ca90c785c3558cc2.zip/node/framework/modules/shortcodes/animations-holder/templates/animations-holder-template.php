<div <?php node_edge_class_attribute($class); ?> <?php echo node_edge_get_inline_attrs($data); ?>>
	<div <?php node_edge_inline_style($style); ?>>
		<?php echo do_shortcode($content); ?>
	</div>

</div>