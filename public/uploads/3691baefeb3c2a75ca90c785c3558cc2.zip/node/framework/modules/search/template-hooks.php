<?php

//Get search HTML
add_action('node_edge_before_page_header', 'node_edge_get_search', 9);