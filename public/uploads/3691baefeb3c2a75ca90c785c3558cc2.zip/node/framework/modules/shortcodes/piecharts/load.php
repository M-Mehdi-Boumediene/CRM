<?php

//Pie Chart Basic
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartbasic/load.php';

//Pie Chart Basic
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartwithicon/load.php';

//Pie Chart Pie
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartpie/load.php';

//Pie Chart Doughnut
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/piecharts/piechartdoughnut/load.php';