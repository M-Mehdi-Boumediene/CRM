<?php
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/tabs/tabs.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/tabs/tab.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/tabs/custom-styles/custom-styles.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/tabs/options-map/map.php';
