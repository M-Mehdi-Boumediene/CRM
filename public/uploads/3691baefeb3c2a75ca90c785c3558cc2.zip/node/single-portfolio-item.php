<?php

get_header();
node_edge_get_title();
get_template_part('slider');
node_edge_single_portfolio();
do_action('node_edge_after_container_close');
get_footer();

?>