
var no_ajax_pages = [];
var edgt_root = 'http://master.dev//';
var theme_root = 'http://master.dev/wp-content/themes/master/';
if(typeof no_ajax_obj !== 'undefined') {
no_ajax_pages = no_ajax_obj.no_ajax_pages;
}