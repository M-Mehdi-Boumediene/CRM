<?php
do_action('node_edge_style_dynamic');


