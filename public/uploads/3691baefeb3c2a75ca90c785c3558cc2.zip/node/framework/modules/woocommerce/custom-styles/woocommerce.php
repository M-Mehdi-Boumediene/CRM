<?php
/**
 * Custom styles for Counter shortcode
 * Hooks to node_edge_style_dynamic hook
 */

//if (!function_exists('node_edge_counter_style')) {
//
//	function node_edge_counter_style()
//	{
//
//		if (node_edge_options()->getOptionValue('option_value') !== '') {
//			echo node_edge_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => node_edge_filter_px(node_edge_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('node_edge_style_dynamic', 'node_edge_counter_style');
//
//}

?>