<div class="edgtf-post-info-category">
	<?php the_category(', '); ?>
</div>