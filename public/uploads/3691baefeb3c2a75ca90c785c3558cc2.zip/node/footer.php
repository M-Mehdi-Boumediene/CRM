<?php
node_edge_get_footer();
?>