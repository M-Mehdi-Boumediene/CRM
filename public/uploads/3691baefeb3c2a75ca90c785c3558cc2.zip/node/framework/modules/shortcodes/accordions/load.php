<?php
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/accordion.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/accordion-tab.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/custom-styles/custom-styles.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/accordions/options-map/map.php';
